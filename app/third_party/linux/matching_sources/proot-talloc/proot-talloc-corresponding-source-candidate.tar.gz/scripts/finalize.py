import copy
import difflib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import sys
import tarfile

base = Path(sys.argv[1]).resolve()
build = base / sys.argv[2]
ndk = Path(sys.argv[3]).resolve()
upstream = base / 'extracted-attempt-2/proot/proot-5.1.107.102'
patched = base / 'patched/proot-5.1.107.102'
rootfs = base / 'extracted-attempt-2/alpine'
out = base / sys.argv[4]
out.mkdir(mode=0o700)
stage = out / 'jniLibs/arm64-v8a'
stage.mkdir(parents=True)
notices = out / 'notices'
notices.mkdir()
assets = out / 'assets'
assets.mkdir()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def elf(p):
    data = p.read_bytes()
    if data[:6] != b'\x7fELF\x02\x01':
        raise ValueError('not ELF64 LE')
    h = struct.unpack_from('<16sHHIQQQIHHHHHH', data)
    typ, machine, entry, phoff, phsize, phnum = h[1], h[2], h[4], h[5], h[9], h[10]
    if phsize != 56:
        raise ValueError('unexpected program header size')
    loads, stack, dynamic = [], [], []
    interp = None
    for n in range(phnum):
        pt, flags, offset, va, pa, fs, ms, align = struct.unpack_from('<IIQQQQQQ', data, phoff + n * phsize)
        if pt == 1:
            loads.append({'offset': offset, 'vaddr': va, 'filesz': fs, 'memsz': ms, 'flags': flags, 'align': align, 'align_hex': hex(align)})
        elif pt == 3:
            interp = data[offset:offset+fs].rstrip(b'\0').decode()
        elif pt == 0x6474e551:
            stack.append(flags)
        elif pt == 2:
            for pos in range(offset, offset+fs, 16):
                tag, val = struct.unpack_from('<qQ', data, pos)
                if tag == 0:
                    break
                dynamic.append((tag, val))
    def address_to_offset(addr):
        for l in loads:
            if l['vaddr'] <= addr < l['vaddr'] + l['filesz']:
                return l['offset'] + addr - l['vaddr']
        raise ValueError('dynamic string table outside load')
    strtabs = [v for k,v in dynamic if k == 5]
    needed = []
    if strtabs:
        st = address_to_offset(strtabs[0])
        for k,v in dynamic:
            if k == 1:
                start = st+v
                needed.append(data[start:data.index(b'\0', start)].decode())
    overlap = []
    for a in loads:
        for b in loads:
            if (a['flags'] & 1) and (b['flags'] & 2):
                a0, a1 = a['vaddr']//16384, (a['vaddr']+a['memsz']+16383)//16384
                b0, b1 = b['vaddr']//16384, (b['vaddr']+b['memsz']+16383)//16384
                if max(a0,b0) < min(a1,b1):
                    overlap.append([a['vaddr'],b['vaddr']])
    textrel = any(k == 22 or (k == 30 and v & 4) for k,v in dynamic)
    flags1 = [v for k,v in dynamic if k == 0x6ffffffb]
    align_ok = bool(loads) and all(l['align'] >= 16384 and (l['vaddr']-l['offset']) % 16384 == 0 for l in loads)
    wx = any((l['flags'] & 3) == 3 for l in loads)
    return {'elf_type': typ, 'machine': machine, 'entry': hex(entry), 'interp': interp, 'needed': needed, 'loads': loads, 'min_load_align': hex(min(l['align'] for l in loads)), 'align_16k_ok': align_ok, 'load_wx': wx, 'wx_page_overlap_16k': overlap, 'gnu_stack_flags': stack, 'stack_rw_nonexec': stack == [6], 'textrel': textrel, 'pie_flag': any(v & 0x8000000 for v in flags1), 'relocation_bytes': sum(v for k,v in dynamic if k in (2, 8, 18)), 'static_structure_ok': machine == 183 and align_ok and not wx and not overlap and stack == [6] and not textrel}

# Complete per-installed-package inventory, including ownership of every ELF.
installed = rootfs / 'lib/apk/db/installed'
packages = []
owners = {}
for block in installed.read_text().strip().split('\n\n'):
    fields = {}
    directory = ''
    files = []
    for line in block.splitlines():
        if len(line) < 2 or line[1] != ':':
            continue
        key, val = line[0], line[2:]
        if key == 'F':
            directory = val
        elif key == 'R':
            files.append('/' + '/'.join(x for x in (directory,val) if x))
        elif key not in fields:
            fields[key] = val
    if 'P' not in fields:
        continue
    rec = {'name': fields['P'], 'version': fields['V'], 'arch': fields.get('A'), 'license': fields.get('L'), 'homepage_from_installed': fields.get('U'), 'origin': fields.get('o'), 'aports_commit_from_installed': fields.get('c'), 'source_delivery_verified': False}
    if not rec['license']:
        raise ValueError('package missing installed license')
    packages.append(rec)
    for f in files:
        owners[f] = rec['name']
shutil.copyfile(installed, notices / 'alpine-installed-original.txt')
(notices / 'alpine-installed-packages.json').write_text(json.dumps(packages,indent=2)+'\n')
for p in packages:
    (notices / (p['name'] + '.notice.txt')).write_text('\n'.join(f'{k}: {v}' for k,v in p.items()) + '\nThis is installed package metadata, not a substitute for required license texts or Corresponding Source before public distribution.\n')

artifacts = []
bindings = []
elffiles = {}
for r,ds,fs in os.walk(rootfs,followlinks=False):
    for name in fs:
        p = Path(r) / name
        if p.is_symlink() or p.read_bytes()[:4] != b'\x7fELF':
            continue
        guest = '/' + p.relative_to(rootfs).as_posix()
        elffiles[guest] = p
for role,p,name in [('proot',build / 'proot/proot','libproot.so'),('proot_loader',build / 'proot/loader/loader','libproot_loader.so')]:
    q = stage / name
    shutil.copyfile(p,q)
    q.chmod(0o444)
    rec = {'role':role,'path':str(q),'sha256':sha(q),'bytes':q.stat().st_size,'elf':elf(q)}
    artifacts.append(rec)
for guest,p in sorted(elffiles.items()):
    name = 'libalpine_' + guest.strip('/').replace('/','_').replace('.','_').replace('-','_') + '.so'
    q = stage / name
    shutil.copyfile(p,q)
    q.chmod(0o444)
    rec = {'role':'guest_elf','guest_path':guest,'package':owners.get(guest),'path':str(q),'sha256':sha(q),'bytes':q.stat().st_size,'elf':elf(q)}
    if not rec['package']:
        raise ValueError('ELF has no installed package owner: '+guest)
    artifacts.append(rec)
    bindings.append({'apk_basename':name,'guest_path':guest,'package':rec['package'],'sha256':rec['sha256']})

# New rootfs asset has data/symlinks only: every regular ELF is omitted.
# Non-directory mode bits never grant execute; do not chmod +x on Android.
downloads = json.loads((base / 'logs/downloads.json').read_text())
original = Path(next(r['archive'] for r in downloads if r['name']=='alpine'))
asset = assets / 'alpine-3.22.8-aarch64-data-only.tar.gz'
with asset.open('xb') as raw, gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz, tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as target, tarfile.open(original) as src:
    for m in src.getmembers():
        guest = '/' + '/'.join(x for x in m.name.split('/') if x and x!='.')
        if guest in elffiles:
            continue
        n = copy.copy(m)
        n.pax_headers = dict(m.pax_headers)
        n.uid = n.gid = 0
        n.uname = n.gname = ''
        n.mode = 0o700 if n.isdir() else (0o777 if n.issym() else 0o600)
        target.addfile(n,src.extractfile(m) if m.isfile() else None)
with tarfile.open(asset) as t:
    for m in t.getmembers():
        if m.isfile():
            if t.extractfile(m).read(4)==b'\x7fELF' or m.mode & 0o111:
                raise ValueError('data asset has executable content')

# Keep every upstream change as a full unified diff; pristine archive/tree stay.
changes = []
diff = []
for r,ds,fs in os.walk(patched,followlinks=False):
    for name in fs:
        p = Path(r)/name
        if p.is_symlink():
            continue
        rel = p.relative_to(patched)
        u = upstream/rel
        if u.read_bytes() != p.read_bytes():
            changes.append({'path':str(rel),'upstream_sha256':sha(u),'patched_sha256':sha(p)})
            diff.extend(difflib.unified_diff(u.read_text().splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(out / 'proot-full.diff').write_text(''.join(diff))
for src,name in [(upstream/'COPYING','PRoot-GPL-2.txt'),(base/'extracted-attempt-2/talloc/talloc-2.5.0/LICENSE','talloc-LGPL-3.txt'),(Path('/usr/share/common-licenses/GPL-3'),'combined-GPL-3.txt')]:
    shutil.copyfile(src,notices/name)

# Plain source archive with the exact patch, adapter and build/packaging scripts.
# No .git, Gradle, project writes, Android execution or publication are involved.
sourcebundle = out / 'proot-talloc-corresponding-source-candidate.tar.gz'
with sourcebundle.open('xb') as raw, gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz, tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as t:
    for r in downloads:
        if r['name'] in ('proot','talloc'):
            t.add(r['archive'],arcname='upstream/'+Path(r['archive']).name)
    t.add(out/'proot-full.diff',arcname='patches/proot-full.diff')
    t.add(base/'config',arcname='config')
    t.add(base/'scripts',arcname='scripts')
    t.add(notices/'PRoot-GPL-2.txt',arcname='licenses/PRoot-GPL-2.txt')
    t.add(notices/'talloc-LGPL-3.txt',arcname='licenses/talloc-LGPL-3.txt')
    t.add(notices/'combined-GPL-3.txt',arcname='licenses/GPL-3.txt')
    t.add(base/'logs'/f'{sys.argv[2]}-result.json',arcname='build/build-result.json')

readelf = ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf'
for a in artifacts:
    p = Path(a['path'])
    log = out / (p.name+'.readelf.txt')
    with log.open('wb') as f:
        r = subprocess.run([str(readelf),'-h','-l','-d','-r','--wide',str(p)],cwd=base/'scripts',stdout=f,stderr=subprocess.STDOUT)
    a['readelf_exit_code'] = r.returncode
    a['readelf_log'] = str(log)

instructions = {
 'status':'PREPARATION_ONLY_NOT_ANDROID_ACCEPTED',
 'app_target_sdk_required':36,
 'ndk_version':'27.1.12297006',
 'compile_api':35,
 'compile_api_note':'NDK r27 exposes stubs through API35; App targetSdk must stay36. No lowered Android target or policy.',
 'abis':['arm64-v8a'],
 'upstream_downloads':downloads,
 'upstream_changes':changes,
 'full_diff':str(out/'proot-full.diff'),
 'full_diff_sha256':sha(out/'proot-full.diff'),
 'reproduce_source_bundle':'Safely unpack the source bundle in a new empty directory. Run python -I UNPACKED/scripts/reproduce.py UNPACKED NEW_WORKSPACE NDK27.1_PATH; it verifies pinned source SHA, applies fullDiff and cross-builds without network/device execution.',
 'build_version_string':'v5.1.107.102-pocketrun-candidate (explicit VERSION macro; not upstream default 5.1.0)',
 'alpine_installed_original_sha256':sha(installed),
 'gpl3_text_provenance':'Installed Debian /usr/share/common-licenses/GPL-3 verbatim copy, original FSF text',
 'build_result':str(base/'logs'/f'{sys.argv[2]}-result.json'),
 'jni_libs_stage':str(stage),
 'artifacts':artifacts,
 'guest_bindings':bindings,
 'rootfs_data_asset':{'path':str(asset),'bytes':asset.stat().st_size,'sha256':sha(asset),'regular_elf_files':0,'regular_executable_permission_files':0,'derivative_not_original_upstream_sha':True},
 'source_bundle':{'path':str(sourcebundle),'sha256':sha(sourcebundle),'bytes':sourcebundle.stat().st_size,'scope':'PRoot+talloc+local adapter/scripts/fullDiff; Alpine package Corresponding Source not collected'},
 'license_scope':{'proot':'GPL-2.0-or-later','talloc':'LGPL-3.0-or-later','static_combined_candidate':'GPL-3.0-or-later-compatible; retain corresponding source and full licenses; do not label aggregate MIT','alpine_installed_packages':len(packages),'alpine_source_and_license_text_delivery_complete':False},
 'short_packaging_steps':[
  'Parent only: copy jniLibs stage and data-only asset into the arm64 signed APK; keep every ELF byte unchanged (no build stripping unless SHA is re-recorded). Do not edit parent CMake from this workspace.',
  'Parent only: set/use extractNativeLibs=true so Android installs immutable executable files in applicationInfo.nativeLibraryDir; preserve targetSdk36; never System.loadLibrary on these executable/guest files.',
  'Parent only: safely unpack data-only archive into filesDir (no ELF, no regular chmod +x, no chown/special files); validate traversal/symlink handling and atomic publication/recovery.',
  'Launch with ProcessBuilder argument list, not shell interpolation: [nativeLibraryDir/libproot.so, --kill-on-exit, -r, rootfsDataDir, -w, /workspace, each -b nativeLibraryDir/<apk_basename>:<guest_path>, -b workspaceDir:/workspace, /bin/busybox, sh, -c, controlled-command]. Add all guest bindings from this manifest.',
  'Set POCKETRUN_EXPECTED_PARENT_PID=Process.myPid(), PROOT_LOADER=nativeLibraryDir/libproot_loader.so, PROOT_TMP_DIR=privateDataTmp, HOME=/root, PATH=/bin:/usr/bin; clear LD_PRELOAD and inherited LD_LIBRARY_PATH. Use PROOT_NO_SECCOMP=1 only for separate ordinary-ptrace fallback trial.',
  'Fresh App-UID/SDK36 native trials must prove normal/default and fallback command paths, mappings and executable backing files in /proc maps, real exit codes, rerun/cancel/timeout, App/tracer/child hard death and no orphan/FD leak. Kernel policy errors are hard failures, never linker64/filesDir exec/RWX/memfd workarounds.'
 ],
 'hard_risks':[
  'No Android/App-UID process, signed APK packaging, SELinux/ptrace/seccomp, product UI, or 16KiB kernel execution has been exercised here. Static success is not Chapter7 completion.',
  'Loader is freestanding relocation-free static PIE, not a Bionic-linked JNI library; moving upstream fixed-address loader to PIE is an unvalidated behavior change.',
  'PDEATHSIG on Linux follows the creating parent thread, not only parent process; Android ProcessBuilder parent-thread lifetime can kill tracer early. Expected App PID is necessary but cannot prove launcher-thread longevity.',
  'PRoot source retains optional memfd/ashmem/sysvipc features but none is selected by the prescribed candidate command; no executable memfd/ashmem strategy is authorized. PRoot is not a security sandbox.',
  'Compiler emitted upstream warnings including a sometimes-uninitialized ret in tracee/seccomp.c setresgid handling. Not repaired or runtime-tested in this fixed-source preparation.',
  'Installed Alpine metadata notices are complete per package, but full license-text/copyright and package Corresponding Source obligations still need completion before any public binary/rootfs distribution.',
  'NativeLibraryDir binding selection and guest dynamic-library opens must be proven on device; writable data ELF execution or executable anonymous mappings are forbidden, not fallback paths.'
 ],
 'device_run':False,'published':False,'project_written':False
}
(out/'candidate-manifest.json').write_text(json.dumps(instructions,indent=2)+'\n')
allok = all(a['elf']['static_structure_ok'] and a['readelf_exit_code']==0 for a in artifacts)
print(json.dumps({'output':str(out),'manifest':str(out/'candidate-manifest.json'),'elf_count':len(artifacts),'guest_elf_count':len(bindings),'static_structure_all_ok':allok,'upstream_changed_files':len(changes),'source_bundle_sha256':sha(sourcebundle),'data_asset_sha256':sha(asset),'proot_sha256':artifacts[0]['sha256'],'loader_sha256':artifacts[1]['sha256'],'elf_alignments':{Path(a['path']).name:a['elf']['min_load_align'] for a in artifacts},'device_run':False},indent=2))
sys.exit(0 if allok else 1)
