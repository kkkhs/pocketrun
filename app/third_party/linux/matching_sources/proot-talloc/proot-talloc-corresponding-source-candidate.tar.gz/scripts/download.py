import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys

base = Path(sys.argv[1]).resolve()
items = [
    ('proot', 'https://codeload.github.com/termux/proot/zip/refs/tags/v5.1.107.102', 'proot-v5.1.107.102.zip', '30d12a6e2cc4147123756ff58edea262d3083bbc238c12d0ab9b39e3d1c40852', None),
    ('alpine', 'https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/aarch64/alpine-minirootfs-3.22.8-aarch64.tar.gz', 'alpine-minirootfs-3.22.8-aarch64.tar.gz', '36091efacd083c1cf5a8c837272530bff4fc72db1fbfdef559f52de0d890bca4', 3971704),
    ('talloc', 'https://www.samba.org/ftp/talloc/talloc-2.5.0.tar.gz', 'talloc-2.5.0.tar.gz', '912afa237510ae542a7733998eb18a12bcda35ab6729c8e2ddb43e8d0ebab007', None),
]

def fetch(item):
    name, url, filename, expected, size = item
    attempts = []
    for n in range(1, 3):
        d = base / f'{name}-attempt-{n}'
        d.mkdir(mode=0o700)
        p = d / (filename + '.partial')
        with (d / 'curl.stderr.txt').open('wb') as stderr:
            r = subprocess.run(['curl', '--fail', '--location', '--proto', '=https', '--proto-redir', '=https', '--connect-timeout', '20', '--max-time', '180', '--dump-header', str(d / 'headers.txt'), '--output', str(p), '--write-out', '%{url_effective}\n%{http_code}\n', url], cwd=base.parent / 'scripts', stdout=subprocess.PIPE, stderr=stderr)
        attempt = {'attempt': n, 'curl_exit': r.returncode, 'curl_result': r.stdout.decode(errors='replace'), 'partial_path': str(p)}
        attempts.append(attempt)
        if r.returncode == 0:
            got = hashlib.sha256(p.read_bytes()).hexdigest()
            attempt.update(bytes=p.stat().st_size, sha256=got, complete_transport=True)
            if got != expected or (size is not None and p.stat().st_size != size):
                return {'name': name, 'url': url, 'expected_sha256': expected, 'attempts': attempts, 'verified': False}
            final = d / filename
            p.rename(final)
            return {'name': name, 'url': url, 'expected_sha256': expected, 'sha256': got, 'bytes': final.stat().st_size, 'archive': str(final), 'attempts': attempts, 'verified': True}
    return {'name': name, 'url': url, 'expected_sha256': expected, 'attempts': attempts, 'verified': False}

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(fetch, items))
(base.parent / 'logs' / 'downloads.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
sys.exit(0 if all(r['verified'] for r in results) else 1)
